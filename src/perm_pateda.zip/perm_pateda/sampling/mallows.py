"""
Mallows Model Sampling for Permutation-based EDAs

This module implements sampling methods for Mallows models with different
distance metrics (Kendall, Cayley, Ulam).

References:
    [1] C. L. Mallows: Non-null ranking models. Biometrika, 1957
    [2] J. Ceberio, A. Mendiburu, J.A Lozano: Introducing the Mallows Model
        on Estimation of Distribution Algorithms. ICONIP 2011
"""

import numpy as np
from typing import Dict, Any, Optional
from perm_pateda.consensus import compose_permutations
from perm_pateda.distances import _generate_perm_from_x, ulam_distance


class SampleMallowsKendall:
    """Sample from Mallows model with Kendall distance"""

    def sample(
        self,
        n_vars: int,
        model: Dict[str, Any],
        cardinality: np.ndarray,
        population: np.ndarray = None,
        fitness: np.ndarray = None,
        **kwargs
    ) -> np.ndarray:
        """Sample method to match EDA interface. Calls __call__ internally."""
        # Handle None values
        if population is None:
            population = np.array([])
        if fitness is None:
            fitness = np.array([])

        # Extract parameters from kwargs if provided
        sample_size = kwargs.get('sample_size', 100)
        rng = kwargs.get('rng', None)

        return self.__call__(
            n_vars=n_vars,
            model=model,
            cardinality=cardinality,
            population=population,
            fitness=fitness,
            sample_size=sample_size,
            rng=rng
        )

    def __call__(
        self,
        n_vars: int,
        model: Dict[str, Any],
        cardinality: np.ndarray,
        population: np.ndarray,
        fitness: np.ndarray,
        sample_size: int,
        rng: Optional[np.random.Generator] = None,
    ) -> np.ndarray:
        """
        Sample permutations from Mallows model with Kendall distance.

        Args:
            n_vars: Number of variables (permutation length)
            model: Model dictionary from learning phase containing:
                   - v_probs: Probability matrix for v-vector
                   - consensus: Consensus ranking
                   - theta: Theta parameter
                   - psis: Normalization constants
            cardinality: Not used for permutations
            population: Current population (not used)
            fitness: Fitness values (not used)
            sample_size: Number of permutations to sample
            rng: Random number generator (optional)

        Returns:
            Array of sampled permutations, shape (sample_size, n_vars)
        """
        if rng is None:
            rng = np.random.default_rng()

        v_probs = model["v_probs"]
        consensus = model["consensus"]

        new_pop = np.zeros((sample_size, n_vars), dtype=int)

        # Generate random values for all samples at once
        rand_values = rng.random((sample_size, n_vars - 1))

        for i in range(sample_size):
            # Sample v-vector
            v_vector = self._sample_v_vector(v_probs, rand_values[i], n_vars)

            # Generate permutation from v-vector
            perm = self._generate_perm_from_v(v_vector, n_vars)

            # Compose with consensus
            new_perm = compose_permutations(perm, consensus)

            new_pop[i] = new_perm

        return new_pop

    def _sample_v_vector(
        self, v_probs: np.ndarray, rand_values: np.ndarray, n_vars: int
    ) -> np.ndarray:
        """Sample a v-vector from the probability matrix."""
        v_vec = np.zeros(n_vars, dtype=int)

        for j in range(n_vars - 1):
            # Sample v[j] from categorical distribution
            cumsum = np.cumsum(v_probs[j, : n_vars - j])
            rand_val = rand_values[j]

            # Find index where cumsum >= rand_val
            index = np.searchsorted(cumsum, rand_val)

            v_vec[j] = index

        v_vec[n_vars - 1] = 0  # Last position is always 0

        return v_vec

    def _generate_perm_from_v(self, v: np.ndarray, n_vars: int) -> np.ndarray:
        """
        Generate permutation from v-vector (Lehmer code).

        The v-vector represents the permutation in a canonical way.
        v[i] indicates how many available positions to skip.
        """
        available = list(range(n_vars))
        perm = np.zeros(n_vars, dtype=int)

        for i in range(n_vars - 1):
            # Find the v[i]-th available position
            val = int(v[i])

            # Count non-removed positions
            index = 0
            count = 0

            while count <= val:
                if available[index] != -1:
                    if count == val:
                        break
                    count += 1
                index += 1

            perm[i] = available[index]
            available[index] = -1  # Mark as used

        # Last position gets the remaining element
        for idx, val in enumerate(available):
            if val != -1:
                perm[n_vars - 1] = val
                break

        return perm


def sample_mallows_kendall(
    n_vars: int,
    model: Dict[str, Any],
    cardinality: np.ndarray,
    population: np.ndarray,
    fitness: np.ndarray,
    sample_size: int,
) -> np.ndarray:
    """
    Convenience function to sample from Mallows model with Kendall distance.

    See SampleMallowsKendall for parameter details.
    """
    sampler = SampleMallowsKendall()
    return sampler(n_vars, model, cardinality, population, fitness, sample_size)


class SampleMallowsCayley:
    """Sample from Mallows model with Cayley distance"""

    def __call__(
        self,
        n_vars: int,
        model: Dict[str, Any],
        cardinality: np.ndarray,
        population: np.ndarray,
        fitness: np.ndarray,
        sample_size: int,
        rng: Optional[np.random.Generator] = None,
    ) -> np.ndarray:
        """
        Sample permutations from Mallows model with Cayley distance.

        Args:
            n_vars: Number of variables (permutation length)
            model: Model dictionary from learning phase containing:
                   - x_probs: Probability vector for x-vector
                   - consensus: Consensus ranking
                   - theta: Theta parameter
                   - psis: Normalization constants
            cardinality: Not used for permutations
            population: Current population (not used)
            fitness: Fitness values (not used)
            sample_size: Number of permutations to sample
            rng: Random number generator (optional)

        Returns:
            Array of sampled permutations, shape (sample_size, n_vars)
        """
        if rng is None:
            rng = np.random.default_rng()

        x_probs = model["x_probs"]
        consensus = model["consensus"]

        new_pop = np.zeros((sample_size, n_vars), dtype=int)

        # Generate random values for all samples at once
        rand_values = rng.random((sample_size, n_vars - 1))

        for i in range(sample_size):
            # Sample x-vector: for each position j, x[j] = 1 with probability x_probs[j]
            x_vector = (rand_values[i] >= x_probs).astype(int)

            # Generate permutation from x-vector
            perm = _generate_perm_from_x(x_vector, n_vars, rng)

            # Compose with consensus
            new_perm = compose_permutations(perm, consensus)

            new_pop[i] = new_perm

        return new_pop


def sample_mallows_cayley(
    n_vars: int,
    model: Dict[str, Any],
    cardinality: np.ndarray,
    population: np.ndarray,
    fitness: np.ndarray,
    sample_size: int,
) -> np.ndarray:
    """
    Convenience function to sample from Mallows model with Cayley distance.

    See SampleMallowsCayley for parameter details.
    """
    sampler = SampleMallowsCayley()
    return sampler(n_vars, model, cardinality, population, fitness, sample_size)


class SampleGeneralizedMallowsKendall:
    """Sample from Generalized Mallows model with Kendall distance

    The Generalized Mallows model uses position-dependent spread parameters,
    allowing different levels of uncertainty at different positions.

    References:
        [1] M.A. Fligner, J.S. Verducci: Distance based ranking models. JRSS, 1986
        [2] J. Ceberio, E. Irurozki, A. Mendiburu, J.A Lozano: A Distance-based
            Ranking Model Estimation of Distribution Algorithm for the Flowshop
            Scheduling Problem. IEEE TEVC, 2014
    """

    def __call__(
        self,
        n_vars: int,
        model: Dict[str, Any],
        cardinality: np.ndarray,
        population: np.ndarray,
        fitness: np.ndarray,
        sample_size: int,
        rng: Optional[np.random.Generator] = None,
    ) -> np.ndarray:
        """
        Sample permutations from Generalized Mallows model with Kendall distance.

        Args:
            n_vars: Number of variables (permutation length)
            model: Model dictionary from learning phase containing:
                   - v_probs: Probability matrix for v-vector (n-1 x n)
                   - consensus: Consensus ranking
                   - theta: Theta parameter vector (length n-1)
                   - psis: Normalization constants (length n-1)
            cardinality: Not used for permutations
            population: Current population (not used)
            fitness: Fitness values (not used)
            sample_size: Number of permutations to sample
            rng: Random number generator (optional)

        Returns:
            Array of sampled permutations, shape (sample_size, n_vars)
        """
        if rng is None:
            rng = np.random.default_rng()

        v_probs = model["v_probs"]
        consensus = model["consensus"]

        new_pop = np.zeros((sample_size, n_vars), dtype=int)

        # Generate random values for all samples at once
        rand_values = rng.random((sample_size, n_vars - 1))

        for i in range(sample_size):
            # Sample v-vector
            v_vector = self._sample_v_vector(v_probs, rand_values[i], n_vars)

            # Generate permutation from v-vector
            perm = self._generate_perm_from_v(v_vector, n_vars)

            # Compose with consensus
            new_perm = compose_permutations(perm, consensus)

            new_pop[i] = new_perm

        return new_pop

    def _sample_v_vector(
        self, v_probs: np.ndarray, rand_values: np.ndarray, n_vars: int
    ) -> np.ndarray:
        """Sample a v-vector from the probability matrix."""
        v_vec = np.zeros(n_vars, dtype=int)

        for j in range(n_vars - 1):
            # Sample v[j] from categorical distribution
            # Each position j has its own probability distribution (from theta_j)
            cumsum = np.cumsum(v_probs[j, : n_vars - j])
            rand_val = rand_values[j]

            # Find index where cumsum >= rand_val
            index = np.searchsorted(cumsum, rand_val)

            # Clamp index to valid range [0, n_vars - j - 1]
            # searchsorted can return len(cumsum) if rand_val >= cumsum[-1]
            index = min(index, n_vars - j - 1)

            v_vec[j] = index

        v_vec[n_vars - 1] = 0  # Last position is always 0

        return v_vec

    def _generate_perm_from_v(self, v: np.ndarray, n_vars: int) -> np.ndarray:
        """
        Generate permutation from v-vector (Lehmer code).

        The v-vector represents the permutation in a canonical way.
        v[i] indicates how many available positions to skip.
        """
        available = list(range(n_vars))
        perm = np.zeros(n_vars, dtype=int)

        for i in range(n_vars - 1):
            # Find the v[i]-th available position
            val = int(v[i])

            # Count non-removed positions
            index = 0
            count = 0

            while count <= val:
                if available[index] != -1:
                    if count == val:
                        break
                    count += 1
                index += 1

            perm[i] = available[index]
            available[index] = -1  # Mark as used

        # Last position gets the remaining element
        for idx, val in enumerate(available):
            if val != -1:
                perm[n_vars - 1] = val
                break

        return perm


class SampleGeneralizedMallowsCayley:
    """Sample from Generalized Mallows model with Cayley distance

    The Generalized Mallows model uses position-dependent spread parameters,
    allowing different levels of uncertainty at different positions.

    References:
        [1] M.A. Fligner, J.S. Verducci: Distance based ranking models. JRSS, 1986
        [2] J. Ceberio, E. Irurozki, A. Mendiburu, J.A Lozano: Extending Distance-based
            Ranking Models in EDAs. CEC 2014
    """

    def __call__(
        self,
        n_vars: int,
        model: Dict[str, Any],
        cardinality: np.ndarray,
        population: np.ndarray,
        fitness: np.ndarray,
        sample_size: int,
        rng: Optional[np.random.Generator] = None,
    ) -> np.ndarray:
        """
        Sample permutations from Generalized Mallows model with Cayley distance.

        Args:
            n_vars: Number of variables (permutation length)
            model: Model dictionary from learning phase containing:
                   - x_probs: Probability matrix for x-vector (n-1 x 2)
                   - consensus: Consensus ranking
                   - theta: Theta parameter vector (length n-1)
                   - psis: Normalization constants (length n-1)
            cardinality: Not used for permutations
            population: Current population (not used)
            fitness: Fitness values (not used)
            sample_size: Number of permutations to sample
            rng: Random number generator (optional)

        Returns:
            Array of sampled permutations, shape (sample_size, n_vars)
        """
        if rng is None:
            rng = np.random.default_rng()

        x_probs = model["x_probs"]
        consensus = model["consensus"]

        new_pop = np.zeros((sample_size, n_vars), dtype=int)

        
        rand_values = rng.random((sample_size, n_vars - 1))

        for i in range(sample_size):
            
            x_vector = np.zeros(n_vars - 1, dtype=int)
            for j in range(n_vars - 1):
                
                if rand_values[i, j] < x_probs[j, 1]:
                    x_vector[j] = 1
                else:
                    x_vector[j] = 0

            
            perm = _generate_perm_from_x(x_vector, n_vars, rng)

            
            new_perm = compose_permutations(perm, consensus)

            new_pop[i] = new_perm

        return new_pop
    
class SampleMallowsUlam:
    """Sample from Mallows model with Ulam distance using MCMC"""
 
    def __init__(self, burn_in: int = 1000, step_size: int = 100):
        # Defaults match the user guide (Section 5.6) and the MallowsUlamEDA wrapper.
        self.burn_in = burn_in
        self.step_size = step_size
 
    def sample(
        self,
        n_vars: int,
        model: Dict[str, Any],
        cardinality: np.ndarray,
        population: np.ndarray = None,
        fitness: np.ndarray = None,
        **kwargs
    ) -> np.ndarray:
        if population is None:
            population = np.array([])
        if fitness is None:
            fitness = np.array([])
 
        sample_size = kwargs.get('sample_size', 100)
        rng = kwargs.get('rng', None)
 
        return self.__call__(
            n_vars=n_vars,
            model=model,
            cardinality=cardinality,
            population=population,
            fitness=fitness,
            sample_size=sample_size,
            rng=rng,
        )
 
    def __call__(
        self,
        n_vars: int,
        model: Dict[str, Any],
        cardinality: np.ndarray,
        population: np.ndarray,
        fitness: np.ndarray,
        sample_size: int,
        rng: Optional[np.random.Generator] = None,
    ) -> np.ndarray:
        if rng is None:
            rng = np.random.default_rng()
 
        consensus = model["consensus"]
        theta = model["theta"]
 
        if theta > 10.0:
            return np.tile(consensus, (sample_size, 1))
 
        new_pop = np.zeros((sample_size, n_vars), dtype=int)
        
        current_perm = consensus.copy()
        current_dist = 0.0
 
        
        for _ in range(self.burn_in):
            current_perm, current_dist = self._metropolis_step(
                current_perm, current_dist, consensus, theta, n_vars, rng
            )
 
        for i in range(sample_size):
            
            for _ in range(self.step_size):
                current_perm, current_dist = self._metropolis_step(
                    current_perm, current_dist, consensus, theta, n_vars, rng
                )
            
            new_pop[i] = current_perm.copy()
 
        return new_pop
 
    def _metropolis_step(
        self, current_perm: np.ndarray, current_dist: float,
        consensus: np.ndarray, theta: float, n_vars: int, rng: np.random.Generator
    ):
        # Random-transposition proposal (swap two positions) instead of a
        # delete+insert move: avoids allocating two new arrays per step.
        i, j = rng.choice(n_vars, size=2, replace=False)
        prop_perm = current_perm.copy()
        prop_perm[i], prop_perm[j] = prop_perm[j], prop_perm[i]
 
        from perm_pateda.distances import ulam_distance
        prop_dist = ulam_distance(prop_perm, consensus)
 
        delta_d = prop_dist - current_dist
 
        if delta_d <= 0:
            return prop_perm, prop_dist
        else:
            if rng.random() < np.exp(-theta * delta_d):
                return prop_perm, prop_dist
            else:
                return current_perm, current_dist
 
 
def sample_mallows_ulam(
    n_vars: int,
    model: Dict[str, Any],
    cardinality: np.ndarray,
    population: np.ndarray,
    fitness: np.ndarray,
    sample_size: int,
    **kwargs
) -> np.ndarray:
    """
    Convenience function to sample from Mallows model with Ulam distance.
 
    See SampleMallowsUlam for parameter details.
    """
    sampler = SampleMallowsUlam()
    
    return sampler.sample(
        n_vars, model, cardinality, population, fitness, sample_size=sample_size, **kwargs
    )

