"""
perm_pateda - Estimation of Distribution Algorithms for permutation problems.

An independent, permutation-focused companion to :mod:`pateda`.  It contributes
the learning and sampling methods specific to permutation spaces (histogram
models and distance-based Mallows / Generalized Mallows models) and reuses
``pateda`` for everything common to all EDAs (the core EDA engine, selection,
replacement, statistics and visualization utilities).

A Python port of the algorithms in ``perm_mateda`` (Irurozki, Ceberio,
Santamaria & Mendiburu, 2018, "Algorithm 989: perm_mateda").

Quick start::

    from perm_pateda import MallowsKendallEDA
    from perm_pateda.functions import create_random_lop
    import numpy as np

    lop = create_random_lop(15, seed=0)
    alg = MallowsKendallEDA(n_vars=15, fitness_func=lop,
                            pop_size=100, n_gen=50, random_seed=0)
    stats, _ = alg.run()
    print("Best:", stats.best_fitness_overall)
"""

__version__ = "0.2.1"
__author__ = "Roberto Santana (roberto.santana@ehu.eus)"

# Plug-and-play permutation EDA wrappers
from perm_pateda.algorithms.permutation import (
    EHMEDA,
    NHMEDA,
    MallowsKendallEDA,
    MallowsCayleyEDA,
    MallowsUlamEDA,
    GMallowsKendallEDA,
    GMallowsCayleyEDA,
    PlackettLuceEDA,
    PlackettLuceMixtureEDA,
    HammingKMMEDA,
    DSMPSEDA,
    DSMASEDA,
)
from perm_pateda.algorithms.random_keys import (
    RKGaussianUMDAEDA,
    RKGaussianFullEDA,
    RKCopulaVinesEDA,
)

# Permutation distance metrics and consensus (central-permutation) estimators
from perm_pateda.distances import (
    kendall_distance,
    cayley_distance,
    ulam_distance,
    hamming_distance,
    compute_derangements,
)
from perm_pateda.consensus import (
    find_consensus_borda,
    find_consensus_median,
    find_consensus_best,
    get_consensus,
)

from perm_pateda.utils.benchmark_parsers import (
    parse_lolib,
    parse_taillard_pfsp,
    parse_qaplib,
    parse_tsplib,
)
from perm_pateda.random_keys import (
    permutation_to_random_keys,
    random_keys_to_permutation,
    random_keys_to_ranks,
    rescale_random_keys,
)

from perm_pateda.utils.stats_utils import (
    summary_table,
    friedman_test,
    wilcoxon_pairwise,
    critical_difference_plot,
)

__all__ = [
    # Algorithms
    "EHMEDA",
    "NHMEDA",
    "MallowsKendallEDA",
    "MallowsCayleyEDA",
    "MallowsUlamEDA",
    "GMallowsKendallEDA",
    "GMallowsCayleyEDA",
    "PlackettLuceEDA",
    "PlackettLuceMixtureEDA",
    "HammingKMMEDA",
    "DSMPSEDA",
    "DSMASEDA",
    "RKGaussianUMDAEDA",
    "RKGaussianFullEDA",
    "RKCopulaVinesEDA",
    # Distances
    "kendall_distance",
    "cayley_distance",
    "ulam_distance",
    "hamming_distance",
    "compute_derangements",
    # Consensus
    "find_consensus_borda",
    "find_consensus_median",
    "find_consensus_best",
    "get_consensus",
    # Utils
    "parse_lolib",
    "parse_taillard_pfsp",
    "parse_qaplib",
    "parse_tsplib",
    "summary_table",
    "friedman_test",
    "wilcoxon_pairwise",
    "critical_difference_plot",
    # Random-key utilities
    "permutation_to_random_keys",
    "random_keys_to_permutation",
    "random_keys_to_ranks",
    "rescale_random_keys",

]
